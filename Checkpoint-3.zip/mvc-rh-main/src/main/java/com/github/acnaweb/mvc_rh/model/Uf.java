package com.github.acnaweb.mvc_rh.model;

public enum Uf {
	SP, RJ, MG
}
